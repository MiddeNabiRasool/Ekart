package com.infy.validator;

import java.util.List;

import org.apache.commons.logging.LogFactory;

import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceRequest;


public class Validator {

	public void validate(ServiceRequest service) throws MobileServiceException{	
		//your code goes here
		String exceptionMessage = null;

		if (Boolean.FALSE.equals(isValidBrand(service.getBrand())))
		{
		    exceptionMessage = "Validator.INVALID_BRAND";
		}
		else if (Boolean.FALSE.equals(isValidIssues(service.getIssues())))
		{
		    exceptionMessage = "Validator.INVALID_NO_OF_ISSUES";
		}
		else if (Boolean.FALSE.equals(isValidIMEINumber(service.getiMEINumber())))
		{
		    exceptionMessage = "Validator.INVALID_IMEI_NUMBER";
		}
		else if (Boolean.FALSE.equals(isValidContactNumber(service.getContactNumber())))
		{
		    exceptionMessage = "Validator.INVALID_CONTACT_NUMBER";
		}
		else if (Boolean.FALSE.equals(isValidCustomerName(service.getCustomerName())))
		{
		    exceptionMessage = "Validator.INVALID_CUSTOMER_NAME";
		}

	
		if (exceptionMessage != null)
		{
		    MobileServiceException exception = new  MobileServiceException(exceptionMessage);

		    LogFactory.getLog(getClass())
			      .error(exception.getMessage(), exception);

		    throw exception;
		}
	}	

	
	// validates the brand
	// brand should always start with a upper case alphabet 
	// and can be followed by one or more alphabets (lower case or upper case) 
	public Boolean isValidBrand(String brand){
		return ((brand!=null) && (brand.matches("[A-Z][A-Za-z]+")));
	}
	
	
	// validates the list of services
	// checks if the list is null or empty
	public Boolean isValidIssues(List<String> issues) {
		return ((issues!=null)&&(! issues.isEmpty()));
	}

	// validates the IMEINumber
	// it should be a 16 digit number 
	public Boolean isValidIMEINumber(Long iMEINumber) {
		return ((iMEINumber!=null)&&(iMEINumber.toString().length()==16));
	}
	
	// validates the contact number
	// should contain 10 numeric characters and should not contain 10 repetitive characters
	public Boolean isValidContactNumber(Long contactNumber) {
	 if(contactNumber!=null)
	 {
		 if(contactNumber.toString().length()==10)
		 {
			 if(! contactNumber.toString().matches("([0-9])\\1{9}"))
			 {
				 return true;
			 }
		 }
	 }
	 return false;
	}
	
	
	// validates the customer name
	// should contain at least one word and each word separated by a single space should contain at least one letter.
	// the first letter of every word should be an upper case character 
	public Boolean isValidCustomerName(String customerName) {
		
		return ((customerName!=null) && (customerName.matches("([A-Z][a-z]+)( [A-Z][a-z]+)*")));
	}
}
