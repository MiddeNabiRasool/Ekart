export class Card{
    cardId:number;
    cardType:string;
    cardNumber:string;
    cvv:string;
    expiryDate:Date;
    nameOnCard:string;

}